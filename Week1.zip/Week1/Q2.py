"""
Write a program that accepts a sentence and replace each occurrence of ‘python’ with ‘pythons’.
"""

# Input the sentence
sentence = input("Enter a sentence: ")

# Replace occurrences of 'python' with 'pythons'
modify_sentence = sentence.replace('python', 'pythons')

# Print the modified sentence
print("Modified sentence:", modify_sentence)